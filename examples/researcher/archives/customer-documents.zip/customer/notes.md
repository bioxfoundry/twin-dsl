# Customer archive note

The customer expects a bioreactor-centric Digital Twin with explicit source citations and a separation between verified geometry and conceptual visualization.
