# Legacy calibration record

Bioreactor temperature sensors were calibrated against the 2025 reference procedure. This record is evidence only and does not override the current manager policy or customer geometry.
